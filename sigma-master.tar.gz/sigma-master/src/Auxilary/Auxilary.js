const Aux = props => props.children ;
export default Aux;
