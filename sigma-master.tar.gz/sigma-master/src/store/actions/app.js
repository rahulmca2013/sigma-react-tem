import * as actionTypes from "./actionTypes";
export const loadGoogleMap = error => {
  return {
    type: actionTypes.SET_LOCATION_FLAG
  };
};