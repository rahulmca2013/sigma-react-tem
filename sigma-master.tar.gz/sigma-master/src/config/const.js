export const BASE_URL = "http://localhost:5000/";
//export const BASE_URL = "http://node.newmediaguru.co:3000/";
export const AUTH_BASE_URL = BASE_URL + "admin/login";
